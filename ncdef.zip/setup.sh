#!/bin/bash
pkg upgrade -y
clear
pkg install android-tools -y
clear
echo 'adb installed ✓'
sleep 3
clear
bash ~/ncdef
